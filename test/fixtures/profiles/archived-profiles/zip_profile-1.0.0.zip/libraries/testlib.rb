# Library resource
