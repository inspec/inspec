control "dep-on-missing-01" do
  describe "a string" do
    it { should cmp "a string" }
  end
end
